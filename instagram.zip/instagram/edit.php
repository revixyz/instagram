<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<div class="container">

    <center>
    <h1>Edit Postingan</h1>
    </center>

    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" class="form-control"><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off"><br>
        
        <input type="submit" value="Update" name="update" class="btn btn-primary">
    </form>
</body>
</html>

<?php } ?>