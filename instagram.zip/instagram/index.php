<?php

include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="icon" href="img/JKT_48-removebg-preview.png" href="syle.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <title>JKT48 members</title>
    <style>
.zoom {
  transition: transform .2s; /* Animation */
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

body {
        background-image: url('img/hii.jpg');
  
      }

      header {
        background: rgba(255,255,225, 0.5);
      }

      article {
        background-color: rgba(255, 255, 255, 0.5);
        background-size:1350px;
        background-repeat:no-repeat repeat-x;
        background-attachment: fixed;
      }
</style>
</head>
<body>

<nav class="navbar sticky-top navbar-expand-lg " style="background-color:pink;">
  <div class="container-fluid">
    <img src="img/ii.png" height="55px" width="">
  <strong><a class ="nav-link disabled" href="#" aria-disabled="true" style="margin-left: 10px;" color="light">MEMBERS</a></strong>
    <a class="text-light navbar-brand" href="#" >
   
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <div a class="text-light nav-link active" aria-current="page" href="#"></a></div>
        </li>
        </li>
      </ul>
      <div align="right">
      <button type="button" class="btn btn-primary bi bi-plus-square" data-bs-toggle="modal" data-bs-target="#exampleModal">Tambah</button>
        <a href="logout.php" onclick="return confirm('anda yakin logout?')" class="btn btn-danger"><i class="fa-solid fa-right-from-bracket" style="color: #ffffff;"></i> Logout</a>
</div>
    </div>
  </div>
</nav><br>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">jkt48</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <strong><h2 align>Tambahkan Postingan</h2></strong>
    <form action="proses_tambah.php" method="POST"
    enctype="multipart/form-data">
    <label for="">Gambar</label><br>
    <input type="file" name="gambar" id="" class="form-control" required><br><br>
    <label for="">Nama</label><br>
    <input type="text" name="caption" id="" class="form-control" autocomplete="off"><br><br>
    <label for="">Detail</label><br>
    <input type="text" name="lokasi" id="" class="form-control" autocomplete="off"><br><br>

    <button type="submit" value="simpan" class="btn btn-primary" name="simpan">Tambah</button>
    </form>
    </div>
    </div>
    </div>
    </div>

<div align="center" class="container">
  <?php while ($post = mysqli_fetch_assoc($query)) { ?>

  <center>      
     <div class="card d-inline-block" style="width: 18rem;">
     <div class="zoom">
     <img src="images/<?= $post['gambar'] ?>" alt=""  class="card-img-top" width="100">
  </div>
  <div align ="left" class="container">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text"><?= $post['caption']?></p>
    <h5 class="card-title"></h5>
    <p class="card-text"><?= $post['lokasi']?></p>
    <!-- <a href="edit.php?no=<?= $post['no'] ?>"> -->
    <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#editModal<?= $post['no'] ?>"><i class="fa-solid fa-pencil"></i></button>
    <a href="hapus.php?no=<?= $post['no'] ?>" onclick="return confirm('anda yakin untuk menghapus?')"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></a>
  </div>
</div>
</div><br><br>
  </center>
  
    
 

 <div class="modal fade" id="editModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">jkt48</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <strong><h2 align>Tambahkan Postingan</h2></strong>
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" class="form-control"><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off"><br>
        
        <input type="submit" value="Update" name="update" class="btn btn-primary">
    </form>
    </div>
    </div>
  </div>
  </div>
    <?php } ?>
 </body>
 </html>